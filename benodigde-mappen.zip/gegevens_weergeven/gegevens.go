package gegevens_weergeven
import (
	"html/template"
	"net/http"
	"Challenge/db_connect"
	"database/sql"
)
type Gebruiker struct {
	Nummer string
	Voornaam string
	Achternaam string
	IDnummer string
	Afdeling string
	Email string
	Device string
	ComputerNaam string
	Telnummer string
}
//functie om de door de gebruiker gemaakte checklist aan hem terug te tonen.
func Gegevens_weergeven(w http.ResponseWriter, r *http.Request){
	db:= db_connect.Mysqldb()
	afdelingsnaam := r.URL.Query().Get("afdelingsnaam")//variabel om de waarde van de URL-variabel binnen krijgt.
	switch afdelingsnaam{
		case "sal": // de waarde van de variabel is "sal" dan Select Alles From sales-tabel.
		query_sal:= "SELECT * FROM sales"
		Querydb(query_sal, db, w)
		case "mkt": // de waarde van de variabel is "mkt" dan Select Alles From marketing-tabel.
		query_mkt:= "SELECT * FROM marketing" 
		Querydb(query_mkt, db, w)
		case "hr": // de waarde van de variabel is "hr" dan Select Alles From hr-tabel.
		query_hr:= "SELECT * FROM hr"
		Querydb(query_hr, db, w)
	}
}
//functie voor het verwerken van de gegevens van MySQL
func Querydb(db *sql.DB, query string, w http.ResponseWriter){
	rows, err:= db.Query(query)
	if err!=nil{
		panic(err)	
	}
	defer rows.Close()
	var gebruikers []Gebruiker
	for rows.Next(){
		var g Gebruiker
		err= rows.Scan(&g.Nummer, &g.Voornaam, &g.Achternaam, &g.IDnummer, &g.Afdeling, &g.Email, &g.Device, &g.ComputerNaam, &g.Telnummer)
		if err!=nil{
			panic(err)
		}
		gebruikers= append(gebruikers, g)
	}
	var tpl = template.Must(template.ParseFiles("html/browse.html"))
	tpl.Execute(w, gebruikers)
}