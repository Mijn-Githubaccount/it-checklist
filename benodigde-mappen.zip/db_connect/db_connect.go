package db_connect
import (
	"database/sql"
	_ "github.com/go-sql-driver/mysql"
)
//verbinding met MySQL
func Mysqldb()*sql.DB{
	db,err:=sql.Open("mysql","root:Uu@12345@tcp(127.0.0.1:3306)/it-checklist")
	if err !=nil && err!=sql.ErrNoRows{ //error handeling
		panic(err)
	}
	return db
}