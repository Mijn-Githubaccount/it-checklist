package afdeling

import (
	"html/template"
	"net/http"
	"Challenge/db_connect"
	"strings"
)
//invoeren van de gegevens van HTML-pagina in de database
func insertdb(tabel string, w http.ResponseWriter, r *http.Request){
	db:= db_connect.Mysqldb()
	r.ParseForm()
	var Nummer = r.Form["Num"]
	var Voornaam = r.Form["Vnaam"]
	var Achternaam = r.Form["Anaam"]
	var IDnummer = r.Form["inum"]
	var Afdeling = r.Form["afdeling"]
	var Email = r.Form["email"]
	var Device = r.Form["device"]
	var ComputerNaam = r.Form["computernaam"]
	var Telnummer= r.Form["telnummer"]
	statement, err := db.Prepare("INSERT INTO "+tabel+" (Nummer, Voornaam, Achternaam, IDnummer, Afdeling, Email, Device, Computernaam, Telnummer) VALUES (?,?,?,?,?,?,?,?,?)")
	if err !=nil{
		panic(err)
	}
	if len(Voornaam) > 0 { //zorg dat alleen goede forms de database in gaan
		_, err = statement.Exec(Nummer[0],Voornaam[0],Achternaam[0],IDnummer[0],Afdeling[0],Email[0],Device[0],ComputerNaam[0],Telnummer[0])
		defer db.Close()
	}
	var tpl = template.Must(template.ParseFiles("html/"+tabel+".html"))
	tpl.ExecuteTemplate(w,tabel+".html", strings.ToUpper(tabel))
}
//functie voor sales-html-pagina.
func Sales(w http.ResponseWriter, r *http.Request){
	insertdb("sales", w, r)
}
//functie voor marketing-html-pagina.
func Marketing(w http.ResponseWriter, r *http.Request){
	insertdb("marketing", w, r)
}
//functie voor hr-html-pagina.
func Hr(w http.ResponseWriter, r *http.Request){
	insertdb("hr", w, r)
}