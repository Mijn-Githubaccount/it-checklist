package inloggen
import (
	"fmt"
	"time"
	"html/template"
	"net/http"
	"Challenge/db_connect"
)
//functie om de gebruikers inloggegevens te controleren met de gegeven van de database.
func Gebruiker_inlog(w http.ResponseWriter, r *http.Request){
	r.ParseForm()
	var Gebruikersnaam = r.Form["Gnaam"] //krijg de gebruikersnaam van het form van de inloggen-html-pagina binnen deze variabel
	var Wachtwoord= r.Form["Wachtwoord"] //krijg het ingevoerde wachtwoord van het form van de inloggen-html-pagina binnen deze variabel
	var naam = Gebruikersnaam[0] //opslaan de gebruikersnaam binnen deze variabel
	Logtijd(Gebruikersnaam[0], time.Now()) //gebruikersnaam en zijn logtijd krijgen.
	if(Controleer_authorisatie(Gebruikersnaam[0],Wachtwoord[0])){ //vergelijken de gebruikersnaam en wachtwoord met ingevoerde gegevens vanuit de inloggen-html-pagina.
		var templ = template.Must(template.ParseFiles("html/home.html")) //als gegevens kloppen krijg de gebruiker de homepagina
		templ.ExecuteTemplate(w,"home.html", naam) //de homepagina met daarin de gebruikersnaam laten zien.
	}else{
		var tpl = template.Must(template.ParseFiles("html/inloggen.html")) 
		tpl.ExecuteTemplate(w, "inloggen.html", "Gebruikersnaam of wachtwoord is onjuist.") //als gegevens niet kloppen krijgt de gebruiker een tekst op dezelfde pagina.
	}	
}
//functie om de inloggegevens van de gebruikers te vergelijken met de gegevens in de database.
func Controleer_authorisatie(Gebruikersnaam string, Wachtwoord string)bool{
	db:= db_connect.Mysqldb()
	var exist bool
	query := "SELECT EXISTS(SELECT Gebruikersnaam FROM gebruikers WHERE Gebruikersnaam='" + Gebruikersnaam +"'AND Wachtwoord='" + Wachtwoord + "')"
	row:=db.QueryRow(query).Scan(&exist) //query wordt uitgevoerd voor iedere rows van de database.
	fmt.Println(row)
	defer db.Close()
	return exist
}
//functie gekoppeld aan de homepagina.
func Inloggen(w http.ResponseWriter, r *http.Request){
	var templ = template.Must(template.ParseFiles("html/inloggen.html"))
	templ.Execute(w,nil)
}
func Accountaanmaken(w http.ResponseWriter, r *http.Request){
	var templ = template.Must(template.ParseFiles("html/accountaanmaken.html"))
	templ.Execute(w,nil)
}
func Gebruiker_aanmelden(w http.ResponseWriter, r *http.Request){
	r.ParseForm()
	var Gebruikersnaam = r.Form["Gnaam"]
	var Wachtwoord= r.Form["Wachtwoord"]
	fmt.Println(Gebruikersnaam[0]," ", Wachtwoord[0])
	var templ = template.Must(template.ParseFiles("html/home.html"))
	templ.Execute(w,nil)
}
//functie om inlogtijd van de gebruikers te achterhalen.
func Logtijd(Gebruikersnaam string, Tijd time.Time){
	db:= db_connect.Mysqldb()
	statement, err := db.Prepare("INSERT INTO inlogtijd (Gebruikersnaam, Inlogtijd) VALUES (?,?)") //invoer-SQL query in de MySQL-tabel "inlogtijd"
	if err !=nil{
		panic(err)
	}
	_, err = statement.Exec(Gebruikersnaam, Tijd) //uitvoeren van de variabel "statement" met deze twee functieparameter.
		defer db.Close()
}